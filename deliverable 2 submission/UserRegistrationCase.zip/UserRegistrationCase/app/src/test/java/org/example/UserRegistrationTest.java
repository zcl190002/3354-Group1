package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserRegistrationTest {

    @BeforeEach
    public void setUp() {
        UserRegistration.clearRegisteredEmails();
    }

    @Test
    public void testValidRegistration() {
        assertTrue(UserRegistration.registerUser("valid@example.com", "StrongPass123"));
    }

    @Test
    public void testInvalidEmail() {
        assertFalse(UserRegistration.registerUser("invalid-email", "StrongPass123"));
    }

    @Test
    public void testWeakPassword() {
        assertFalse(UserRegistration.registerUser("user@example.com", "123"));
    }

    @Test
    public void testDuplicateEmail() {
        UserRegistration.registerUser("duplicate@example.com", "StrongPass123");
        assertFalse(UserRegistration.registerUser("duplicate@example.com", "NewPass123"));
    }

    @Test
    public void testMissingEmail() {
        assertFalse(UserRegistration.registerUser("", "StrongPass123"));
    }

    @Test
    public void testMissingPassword() {
        assertFalse(UserRegistration.registerUser("user@example.com", ""));
    }
}