package org.example;

import java.util.HashSet;
import java.util.regex.Pattern;

public class UserRegistration {

    private static HashSet<String> registeredEmails = new HashSet<>();

    public static boolean registerUser(String email, String password) {
        if (!isValidEmail(email)) {
            System.out.println("Invalid email format.");
            return false;
        }

        if (!isPasswordStrong(password)) {
            System.out.println("Password does not meet strength requirements.");
            return false;
        }

        if (isEmailInUse(email)) {
            System.out.println("Email is already registered.");
            return false;
        }

        registeredEmails.add(email);
        System.out.println("Registration successful.");
        return true;
    }

    private static boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        Pattern pattern = Pattern.compile(emailRegex);
        return pattern.matcher(email).matches();
    }

    private static boolean isPasswordStrong(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Za-z].*") &&
               password.matches(".*[0-9].*");
    }

    private static boolean isEmailInUse(String email) {
        return registeredEmails.contains(email);
    }

    public static void clearRegisteredEmails() {
        registeredEmails.clear();
    }
}