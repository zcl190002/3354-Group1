package org.example;

public class UserRegistrationApp {
    public static void main(String[] args) {
        System.out.println("User Registration Application Running!");
    }
}